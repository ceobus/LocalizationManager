<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 22:12
 */

if ( ! function_exists('is_logged_in'))
{


        function is_logged_in() {
            $CI =& get_instance();
            if($CI->session->userdata('logged_in')==true)
            {

                return true;
            }
            else
                {
                    return false;
                }
        }

}

if ( ! function_exists('user_name'))
{


    function user_name($id) {
        $CI =& get_instance();
        $query =  $CI->db->query('Select * FROM users WHERE  id='.$id);
        if($query->row())
        {
          return $query->row()->username;
        }
        else
            {
                return 'Kullanıcı Yok veya Silinmiş';
            }


    }

}
if ( ! function_exists('language_name'))
{


    function language_name($id) {
        $CI =& get_instance();
        $query =  $CI->db->query('Select * FROM language WHERE  id='.$id);
        if($query->row())
        {
            return $query->row()->name;
        }
        else
        {
            return 'Dil Tanımlanmamış veya Silinmiş';
        }


    }

}

if ( ! function_exists('version_name'))
{


    function version_name($id) {
        $CI =& get_instance();
        $query =  $CI->db->query('Select * FROM version WHERE  id='.$id);
        if($query->row())
        {
            return $query->row()->name;
        }
        else
        {
            return 'Version Tanımlanmamış veya Silinmiş';
        }


    }

}

if ( ! function_exists('project_name'))
{


    function project_name($id) {
        $CI =& get_instance();
        $query =  $CI->db->query('Select * FROM project_detail WHERE  language_id=1 and project_id='.$id);
        if($query->row())
        {
            return $query->row()->name;
        }
        else
        {
            return 'Türkçe Dilinde ve Version 1.00 da Proje Tanımlanmamış';
        }


    }

}

if ( ! function_exists('project_id'))
{


    function project_id($id) {
        $CI =& get_instance();
        $query =  $CI->db->query('Select * FROM project_detail WHERE  id='.$id);
        if($query->row())
        {
            return $query->row()->project_id;
        }
        else
        {
            return 'ID Mevcut Değil';
        }


    }

}

