<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 22:03
 */
class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');

        $this->load->model('dashboard_model', 'd_model');

         if(!is_logged_in())
         {
             redirect("login");
         }


        $this->load->view('login/header');
        $this->load->view('login/footer');

    }

    public function index()
    {

        $data['user_list']=$this->d_model->UserList();
        $data['edit_link']=base_url().'dashboard/edit';
        $data['delete_link']=base_url().'dashboard/delete';
        $data['new_link']=base_url().'dashboard/add';
        $this->load->view('dashboard/index',$data);
    }

    public function edit($id)
    {
        if($this->input->post('id'))
        {
                $this->d_model->update($this->input->post('id'));

                $this->session->set_flashdata('success','Kullanıcı Başarıyla Güncellendi !');



        }
        $data['user_data']=$this->d_model->UserDetail($id);
        $data['edit_link']=base_url().'dashboard/edit';
        $data['delete_link']=base_url().'dashboard/delete';
        $data['new_link']=base_url().'dashboard/add';
        $this->load->view('dashboard/edit',$data);
    }

    public function delete($id)
    {
        if(isset($id))
        {

            $this->d_model->delete($id);

            redirect("dashboard");


        }

    }
    public function add()
    {
        if($this->input->post('username'))
        {
            $this->d_model->add();

            $this->session->set_flashdata('success','Kullanıcı Başarıyla Eklendi !');



        }
        $this->load->view('dashboard/add');
    }
}