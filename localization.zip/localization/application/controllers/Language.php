<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 20:20
 */
require_once APPPATH.'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';
class Language extends \Restserver\Libraries\REST_Controller
{

    public  function __construct()
    {
        parent::__construct();

        $this->load->model('Languageapi_model','l_model');
    }

    public function index_get()
    {
        $language=$this->l_model->get();

        if(!is_null($language))
        {
            $this->response(array('response'=>$language),200);
        }
        else
            {
                $this->response(array('error'=>'Data Bulunamadı'),404);
            }
    }
    public function locale_get($project_id,$version,$lang_code,$keyword)
    {
        $keyword=urldecode($keyword);
        $language_detail=$this->l_model->locale_get($project_id,$version,$lang_code,$keyword);
        if(!is_null($language_detail))
        {
            $this->response(array('response'=>$language_detail),200);
        }
        else
        {
            $this->response(array('error'=>'Data Bulunamadı'),404);
        }
    }

}