<?
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 20:09
 */

class Login extends CI_Controller
{
    public function  __construct()
    {
        parent::__construct();

        $this->load->model('login_model', 'login');
        $this->load->library('session');




    }

    public function index()
    {



        if($this->session->userdata('logged_in')==true)
        {

            redirect('dashboard/', 'refresh');
        }

        else if ($this->input->post('username'))
        {

            $user = $this->input->post('username');
            $password = $this->input->post('password');
            $values=$this->login->login_control($user, $password);
            if(isset($values))
            {
                $data_array=array();
                $data = array(
                    'username'  => $values->username,
                    'user_id'  => $values->id,
                    'email'     => $values->password,
                    'logged_in' => TRUE
                );

                $this->session->set_userdata($data);
                $data_array['name']=$values->username;
                redirect('dashboard/', 'refresh');
            }
            else
                {
                    $this->load->view('login/index');
                }



        } else {
            $this->load->view('login/index');
        }

        $this->load->view('login/header');
        $this->load->view('login/footer');
    }

    public function logout()
    {

        $_SESSION['logged_in'] = false;
        redirect('login', 'refresh');

    }
}