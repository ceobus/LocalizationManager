<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 13:15
 */
class Project extends CI_Controller
{
    public function __construct()
    {
         parent::__construct();
            $this->load->library('session');
            $this->load->library('csvimport');


            if(!is_logged_in())
            {
                redirect('login/', 'refresh');
            }


            $this->load->model('project_model', 'p_model');



    }

    public function index()
    {
        $this->load->view('login/header');
        $this->load->view('login/footer');
        if($this->input->post('project_name'))
        {

        }
        else
            {
                $data['project_list']=$this->p_model->ProjectList();
                $data['export_link']=base_url().'project/project_export';
                $data['import_link']=base_url().'project/import_view';
                $data['edit_link']=base_url().'project/edit';
                $data['clone_link']=base_url().'project/clone';
                $data['delete_link']=base_url().'project/delete';
                $data['new_link']=base_url().'project/add';
                $this->load->view('project/index',$data);
            }
    }

    public function edit($id)
    {

        if($this->input->post('id'))
        {
            $this->p_model->update($id);
            $this->session->set_flashdata('success','Başarıyla Güncellendi !');

        }
        $this->load->view('login/header');
        $this->load->view('login/footer');
        $user_data['version']=$this->p_model->VersionList();
        $user_data['language']=$this->p_model->LanguageList();
        $project_id=project_id($id);
        $user_data['project_id']=$project_id;
        $user_data['id']=$id;
        $user_data['detail']=$this->p_model->poject_detailid($id);
        $this->load->view('project/edit',$user_data);
    }

    public function clone($id)
    {
        $this->p_model->clone($id);
        $this->session->set_flashdata('success','Başarıyla Klonlandı !');
        redirect('project/', 'refresh');

    }

    public function add()
    {
        if($this->input->post('project_name'))
        {
            $this->p_model->insert();
            $this->session->set_flashdata('success','Başarıyla Eklendi !');

        }
        $this->load->view('login/header');
        $this->load->view('login/footer');
        $user_data['version']=$this->p_model->VersionList();
        $user_data['projelist']=$this->p_model->ProjectListGroup();
        $user_data['language']=$this->p_model->LanguageList();
        $this->load->view('project/add',$user_data);
    }
    public function delete($id)
    {
        $this->p_model->delete($id);
        $this->session->set_flashdata('success','Silindi !');
        redirect('project','refresh');

    }

    public function ajax_detail()
    {
        $lan_id=$_POST['lan_id'];
        $vers_id=$_POST['vers_id'];
        $id=$_POST['id'];
        $query=$this->p_model->poject_detail($id,$lan_id,$vers_id);
        $returnArr = array(
            'project_name'=>isset($query->name)?$query->name:'Tanımlanmamış',
            'project_detail'=>isset($query->description)?$query->description:'Tanımlanmamış'
        );

        print (json_encode( $returnArr , JSON_UNESCAPED_UNICODE)) ;

    }
    public function project_export()
    {

        $filename = 'project'.date('Ymd').'.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");
        header('Content-Type: text/html; charset=UTF-8');
        $ProjectData=$this->p_model->ProjectList();

        $file = fopen('php://output', 'w');
        $header = array("id","project_id","name","description","version","language_id","user_id");
        fputcsv($file, $header);
        foreach ($ProjectData as $key=>$line){
            $line = mb_convert_encoding($line, "UTF-8", "auto");
            fputcsv($file,$line);
        }
        fclose($file);
        exit;


    }
    public function import_view()
    {
        $this->load->view('login/header');
        $this->load->view('login/footer');
        $this->load->view('project/excel_import');
    }

    public function import()
    {
        $file_data = $this->csvimport->get_array($_FILES["csv_file"]["tmp_name"]);


        foreach($file_data as $row)
        {
            $data[] = array(
                'project_id'		=>	$row["project_id"],
                'name'			=>	$row["name"],
                'description'			=>	$row["description"],
                'version'			=>	$row["version"],
                'language_id'			=>	$row["language_id"],
                'user_id'			=>	$row["user_id"]
            );
        }
        $this->p_model->insert_excel($data);
    }
}