<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 24.01.2019
 * Time: 12:58
 */
?>

<div class="container box">
    <h3 align="center">Proje Listesi İmport</h3>
    <br />

    <form method="post" id="import_csv" enctype="multipart/form-data">
        <div class="form-group">
            <label>Lütfen Dosta Seçiniz</label>
            <input type="file" name="csv_file" id="csv_file" required accept=".csv" />
        </div>
        <br />
        <button type="submit" name="import_csv" class="btn btn-info" id="import_csv_btn">Yükle</button>
    </form>
    <br />
</div>
</body>
</html>

<script>
    $(document).ready(function(){





        $('#import_csv').on('submit', function(event){
            event.preventDefault();
            $.ajax({
                url:"<?php echo base_url(); ?>project/import",
                method:"POST",
                data:new FormData(this),
                contentType:false,
                cache:false,
                processData:false,
                beforeSend:function(){
                    $('#import_csv_btn').html('Yükleniyor...');
                },
                success:function(data)
                {
                    $('#import_csv')[0].reset();
                    $('#import_csv_btn').attr('disabled', false);
                    $('#import_csv_btn').html('Tamamlandı');
                }
            })
        });

    });
</script>
