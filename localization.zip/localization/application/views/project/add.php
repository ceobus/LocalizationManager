<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 13:15
 */
?>

<div class="container">
    <?php
    $message = $this->session->userdata('success');
    if ($message) { ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Başarılı</p>
            <p><?php echo $message; ?></p>
        </div>

    <?php } else if ($this->session->userdata('error')) { ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Hatalı</p>
            <p><?php echo $this->session->userdata('error'); ?></p>
        </div>
    <?php } ?>
    <form  method="post">


        <div class="form-group">
            <label for="exampleInputEmail1">Proje Seçiniz</label>
            <select  class="form-control" name="project_id" id="project_id">
                <option value="0">Yeni Proje</option>
                <?php foreach ($projelist as $value) { ?>
                    <option value="<?php echo $value['project_id']; ?>"><?php echo $value['name']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Dil Seçiniz</label>
            <select  class="form-control" name="language_id" id="language_id">
                <option value="">Seçiniz</option>
                <?php foreach ($language as $lang) { ?>
                    <option value="<?php echo $lang->id; ?>"><?php echo $lang->name; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Versiyon Seçiniz</label>
            <select  class="form-control" name="version_id" id="version_id">
                <option value="">Seçiniz</option>
                <?php foreach ($version as $value) { ?>
                    <option value="<?php echo $value->id; ?>"><?php echo $value->name; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label for="name">Proje Adı</label>
            <input  type="text" name="project_name" class="form-control" id="project_name" >
        </div>
        <div class="form-group">
            <label for="desc">Proje Açıklaması</label>
            <input  type="text" class="form-control"   name="proje_desc" id="proje_desc">
        </div>

        <button type="submit" class="btn btn-primary">Kaydet</button>
    </form>

</div>
