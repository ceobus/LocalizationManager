<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 13:15
 */
?>


<div class="container">
    <?php
    $message = $this->session->userdata('success');
    if ($message) { ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Başarılı</p>
            <p><?php echo $message; ?></p>
        </div>

    <?php } else if ($this->session->userdata('error')) { ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Hatalı</p>
            <p><?php echo $this->session->userdata('error'); ?></p>
        </div>
    <?php } ?>
    <form  method="post">

        <h4>Proje Adı: <?php echo project_name($project_id) ?></h4>
        <p>Versiyon 1.00 ve Türkçe Dili Baz Alınmıştır</p>

        <div class="form-group">
            <label for="exampleInputEmail1">Dil Seçiniz</label>
           <select  class="form-control" name="language_id" id="language_id">
               <option value="">Seçiniz</option>
               <?php foreach ($language as $lang) { ?>
                    <option <?php if($detail->language_id==$lang->id) echo 'selected'; else ''; ?> value="<?php echo $lang->id; ?>"><?php echo $lang->name; ?></option>
                <?php } ?>
           </select>
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Versiyon Seçiniz</label>
            <select  class="form-control" name="version_id" id="version_id">
                <option value="">Seçiniz</option>
                <?php foreach ($version as $value) { ?>
                    <option <?php if($detail->version==$value->id) echo 'selected'; else ''; ?>  value="<?php echo $value->id; ?>"><?php echo $value->name; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label for="name">Proje Adı</label>
            <input  type="text" name="project_name" value="<?php echo $detail->name?>"  class="form-control" id="project_name" >
            <input type="hidden" name="id" value="<?php echo $id; ?>"  >
        </div>
        <div class="form-group">
            <label for="desc">Proje Açıklaması</label>
            <input  type="text" class="form-control"  value="<?php echo $detail->description?>"   name="proje_desc" id="proje_desc">
        </div>

        <button type="submit" class="btn btn-primary">Kaydet</button>
    </form>

</div>

<script>
    function proje_detail(obj) {
        var lan_id =$('#language_id').val();
        var vers_id =$('#version_id').val();
        var id =<?php echo $project_id;?>;
        if(lan_id=='')
        {
            //alert('Dil Seçiniz');
        }
        if(vers_id=='')
        {
           // alert('Version Seçiniz');
        }

        if(vers_id!='' && lan_id!='')
        {
            //ajax
            jQuery.ajax({
                url: '/localization/Project/ajax_detail',
                type: 'POST',
                async:true,
                data: {
                    id: id,
                    lan_id: lan_id,
                    vers_id: vers_id
                },
                success: function (data) {

                    var res= JSON.parse(data);

                    $('#project_name').val(res.project_name);
                    $('#proje_desc').val(res.project_detail);

                }
            });
        }



    }


</script>
