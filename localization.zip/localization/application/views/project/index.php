<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 13:15
 */

?>

<div class="row">

    <div class="container">
        <?php
        $message = $this->session->userdata('success');
        if ($message) { ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">
                </button>
                <p>Başarılı</p>
                <p><?php echo $message; ?></p>
            </div>

        <?php } else if ($this->session->userdata('error')) { ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">
                </button>
                <p>Hatalı</p>
                <p><?php echo $this->session->userdata('error'); ?></p>
            </div>
        <?php } ?>
        <h2>Proje Listesi</h2>

        <a class="btn btn-success" style="float: right" href="<?php echo $new_link;?>" data-toggle="tooltip"  title="Yeni Proje" class="button btn-btn"><i class="fa fa-plus" aria-hidden="true"></i></a>

        <a class="btn btn-success" style="float: right" href="<?php echo $export_link;?>"  data-toggle="tooltip"  title="CSV İndir" class="button btn-btn"><i class="fa fa-file-excel-o" aria-hidden="true"></i></a>

        <a class="btn btn-success" style="float: right" href="<?php echo $import_link;?>"  data-toggle="tooltip"  title="CSV Yükle" class="button btn-btn"><i class="fa fa-file-excel-o" aria-hidden="true"></i></a>


        <table class="table table-hover">
            <thead>
            <tr>
                <th>#</th>
                <th>Proje Id</th>
                <th>Proje Adı</th>
                <th>Proje Açıklaması</th>
                <th>Sorumlu Kullanıcı</th>
                <th>Dil</th>
                <th>Version</th>
                <th>İşlem</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(isset($project_list)) {

                foreach ($project_list as $value) { ?>
                    <tr>
                        <td><?php echo $value['id']; ?></td>
                        <td><?php echo $value['project_id']; ?></td>
                        <td><?php echo $value['name']; ?></td>
                        <td><?php echo $value['description']; ?></td>
                        <td><?php echo user_name($value['user_id']); ?></td>
                        <td><?php echo language_name($value['language_id']); ?></td>
                        <td><?php echo version_name($value['version']); ?></td>
                        <td>
                            <a class="btn btn-primary" href="<?php echo $edit_link . '/' . $value['id']; ?>"><i class="fa fa-pencil"
                                                                                                                aria-hidden="true"></i></a>
                            <a onClick="return confirm('Bu kaydı silmek istediğinizden emin misiniz?')" class="btn btn-danger" href="<?php echo $delete_link . '/' . $value['id']; ?>"><i class="fa fa-trash"
                                                                                                                                                                                          aria-hidden="true"></i></a>
                            <a onClick="return confirm('Bu kaydı klonlamak istediğinizden emin misiniz?')" class="btn btn-info" href="<?php echo $clone_link . '/' . $value['id']; ?>"><i class="fa fa-clone"
                                                                                                                                                                                          aria-hidden="true"></i></a>
                        </td>
                    </tr>

                <?php }
            }
            ?>

            </tbody>
        </table>
    </div>
</div>
