<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 20:14
 */
?>


<!DOCTYPE html>
<html lang="en" data-textdirection="ltr" class="loading">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head>

    <title>Giriş</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">


    <script src="<?php echo base_url().'assets/js'; ?>/jquery-3.3.1.js" crossorigin="anonymous"></script>

   <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


</head>

<body>
<?php
if(is_logged_in())
{
    ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">


        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="/localization">Kullanıcı Listesi <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/localization/project">Projeler <span class="sr-only">(current)</span></a>
                </li>
            </ul>

            <form class="form-inline my-2 my-lg-0">
                <a class="btn btn-danger" style="float: right" href="/localization/login/logout" class="button btn-btn"><i class="fa fa-sign-out" aria-hidden="true"></i></a>

            </form>


        </div>
    </nav>


    <?php
}

?>
