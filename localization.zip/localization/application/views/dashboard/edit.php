<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 22:51
 */
?>

<div class="container">
    <?php
    $message = $this->session->userdata('success');
    if ($message) { ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Başarılı</p>
            <p><?php echo $message; ?></p>
        </div>

    <?php } else if ($this->session->userdata('error')) { ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Hatalı</p>
            <p><?php echo $this->session->userdata('error'); ?></p>
        </div>
    <?php } ?>
<form  method="post">
    <div class="form-group">
        <label for="exampleInputEmail1">Kullanıcı Adı</label>
        <input type="text" name="username" value="<?php echo $user_data->username; ?>" class="form-control" id="username" >
        <input type="hidden" name="id" value="<?php echo $user_data->id; ?>" >
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Şifre</label>
        <input type="password" class="form-control" value="<?php echo $user_data->password; ?>" name="password" id="password">
        <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
    </div>

    <button type="submit" class="btn btn-primary">Kaydet</button>
</form>

</div>

<style>
    .field-icon {
        float: right;
        margin-left: -25px;
        margin-top: -25px;
        position: relative;
        z-index: 2;
    }
</style>
<script>
    $(".toggle-password").click(function() {

        $(this).toggleClass("fa-eye fa-eye-slash");
        var input = document.getElementById("password");
        if (input.type == "password") {
            input.type='text';
        } else {
            input.type='password'
        }
    });
</script>
