<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 20:37
 */
?>


<div class="row">
<div class="container">
    <h2>Kullanıcı Listesi</h2>

        <a class="btn btn-success" style="float: right" href="<?php echo $new_link;?>" class="button btn-btn"><i class="fa fa-plus" aria-hidden="true"></i></a>


    <table class="table table-hover">
        <thead>
        <tr>
            <th>ID</th>
            <th>Kullanıcı Adı</th>
            <th>Şifre</th>
            <th>İşlem</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if(isset($user_list)) {

            foreach ($user_list as $value) { ?>
                <tr>
                    <td><?php echo $value['id']; ?></td>
                    <td><?php echo $value['username']; ?></td>
                    <td style="-webkit-text-security: disc;"><?php echo $value['password']; ?></td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo $edit_link . '/' . $value['id']; ?>"><i class="fa fa-pencil"
                                                                                    aria-hidden="true"></i></a>
                        <a onClick="return confirm('Bu kaydı silmek istediğinizden emin misiniz?')" class="btn btn-danger" href="<?php echo $delete_link . '/' . $value['id']; ?>"><i class="fa fa-trash"
                                                                                      aria-hidden="true"></i></a>
                    </td>
                </tr>

            <?php }
        }
        ?>

        </tbody>
    </table>
</div>
</div>
