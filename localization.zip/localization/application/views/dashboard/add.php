<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 12:54
 */
?>

<div class="container">
    <?php
    $message = $this->session->userdata('success');
    if ($message) { ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Başarılı</p>
            <p><?php echo $message; ?></p>
        </div>

    <?php } else if ($this->session->userdata('error')) { ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">
            </button>
            <p>Hatalı</p>
            <p><?php echo $this->session->userdata('error'); ?></p>
        </div>
    <?php } ?>
    <form  method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">Kullanıcı Adı</label>
            <input type="text" name="username" class="form-control" id="username" >
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Şifre</label>
            <input type="text" class="form-control" name="password" id="password">
        </div>

        <button type="submit" class="btn btn-primary">Kaydet</button>
    </form>

</div>
