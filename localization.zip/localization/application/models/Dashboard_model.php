<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 22:27
 */

class Dashboard_model extends CI_Model

{

    private $table = 'users';

    private $fields = [
        'username' ,'password'
    ];


    public function __construct()

    {

        parent::__construct();

    }

    public function UserList()
    {



        $this->db->select('*');
        $this->db->from($this->table);
        $query = $this->db->get();
        return $query->result_array();

    }

    public function UserDetail($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->row();
    }

    public function update($id)
    {
        $data['username']= $this->input->post('username');
        $data['password']= $this->input->post('password');
        $this->db->where('id',$id);
        $this->db->update($this->table,$data);
    }

    public function delete($id)
    {
        $this->db->where('id',$id);
        $this->db->delete($this->table);
    }
    public function add()
    {
        $data['username']= $this->input->post('username');
        $data['password']= $this->input->post('password');
        $this->db->insert($this->table,$data);

    }




}