<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 13:15
 */

class Project_model extends CI_Model
{
    private $table = 'project_detail';

    private $language_id=1;

    public function __construct()
    {
        parent::__construct();

    }



    public function ProjectList()
    {



        $this->db->select('*');
        $this->db->from($this->table);
       // $this->db->where('language_id',$this->language_id);
       // $this->db->group_by('project_detail.project_id');
        $query = $this->db->get();
        return $query->result_array();

    }


    public function ProjectListGroup()
    {



        $this->db->select('*');
        $this->db->from($this->table);
        // $this->db->where('language_id',$this->language_id);
        $this->db->group_by('project_detail.project_id');
        $query = $this->db->get();
        return $query->result_array();

    }


    public function VersionList()
    {
        return $this->db->select('*')
            ->from('version')
            ->get()
            ->result();
    }
    public function LanguageList()
    {
        return $this->db->select('*')
            ->from('language')
            ->get()
            ->result();
    }
    public function poject_detail($id,$lan_id,$vers_id)
    {
        return $this->db->select('*')
            ->from('project_detail')
            ->where(array('project_id'=>$id,'language_id'=>$lan_id,'version'=>$vers_id))
            ->get()
            ->row();
    }


    public function poject_detailid($id)
    {
        return $this->db->select('*')
            ->from('project_detail')
            ->where('id',$id)
            ->get()
            ->row();
    }
    public function  clone($id)
    {
        $this->db->select('*');
        $this->db->from('project_detail');
        $this->db->where('id',$id);
        $query=$this->db->get()->row();
        $data['project_id']=$query->project_id;
        $data['name']=$query->name;
        $data['description']=$query->description;
        $data['version']=$query->version;
        $data['language_id']=$query->language_id;
        $this->db->insert('project_detail', $data);
    }

    public function update($id)
    {
        $data['name']= $this->input->post('project_name');
        $data['description']= $this->input->post('proje_desc');
        $data['version']= $this->input->post('version_id');
        $data['language_id']= $this->input->post('language_id');
        $this->db->where('id',$id);
        $this->db->update($this->table,$data);
    }
    public function insert()
    {
        $id = $this->input->post('project_id');
        $project_id=0;
        $query=$this->db->select('*')
        ->from('project')
            ->where('id',$id)
            ->get()
            ->row();
        if(isset($query))
        {
            $project_id=$query->id;
        }
        else
            {
                $data_project['user_id']=$_SESSION['user_id'];
                $this->db->insert('project',$data_project);
                $project_id=$this->db->insert_id();
            }
        $data['name']= $this->input->post('project_name');
        $data['user_id']= $_SESSION['user_id'];
        $data['project_id']= $project_id;
        $data['description']= $this->input->post('proje_desc');
        $data['version']= $this->input->post('version_id');
        $data['language_id']= $this->input->post('language_id');
        $this->db->insert($this->table,$data);

    }

    public function insert_excel($datas)
    {
        foreach ($datas as $data)
        {
            $id = $data['project_id'];
            $project_id=0;
            $query=$this->db->select('*')
                ->from('project')
                ->where('id',$id)
                ->get()
                ->row();
            if(isset($query))
            {
                $project_id=$query->id;
            }
            else
            {
                $data_project['user_id']=$_SESSION['user_id'];
                $this->db->insert('project',$data_project);
                $project_id=$this->db->insert_id();
            }
            $data_ins['name']= $data['name'];
            $data_ins['user_id']= $_SESSION['user_id'];
            $data_ins['project_id']= $project_id;
            $data_ins['description']= $data['description'];
            $data_ins['version']= $data['version'];
            $data_ins['language_id']= $data['language_id'];
            $this->db->insert($this->table,$data_ins);
        }



    }

    public function delete($id)
    {
        $this->db->delete($this->table, array('id' => $id));
    }
}


