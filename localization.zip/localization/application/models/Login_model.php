<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 22.01.2019
 * Time: 20:42
 */

class Login_model extends CI_Model

{

    var $table = 'users';


    public function __construct()

    {

        parent::__construct();

    }

    public function login_control($username,$pass)
    {



        $where="username='".$username."' and password='".$pass."'";
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->row();

    }
    public function checklogin()
    {
        return false;
    }



}