<?php
/**
 * Created by PhpStorm.
 * User: ceobus
 * Date: 23.01.2019
 * Time: 20:31
 */

class Languageapi_model extends CI_Model

{

    public function get()
    {
        return $this->db->select('*')
            ->from('language')
            ->get()
            ->result();
    }

    public function locale_get($project_id,$version,$lang_code,$keyword)
    {
        return $this->db->select('*')
            ->from('project_detail')
            ->where(array('project_id'=>$project_id,'version'=>$version,'language_id'=>$lang_code))
            ->like('name',$keyword)
            ->get()
            ->result();
    }
}