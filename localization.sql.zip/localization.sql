-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 23 Oca 2019, 11:55:24
-- Sunucu sürümü: 10.1.32-MariaDB
-- PHP Sürümü: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `localization`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `language`
--

INSERT INTO `language` (`id`, `name`, `code`) VALUES
(1, 'Türkçe', 'tr'),
(2, 'İngilizce', 'en'),
(3, 'Almanca', 'de'),
(4, 'Fransızca', 'fr'),
(5, 'Arapça', 'ar'),
(6, 'Yunanca', 'el'),
(7, 'İtalyanca', 'it'),
(8, 'Portekizce', 'pt'),
(9, 'İspanyolca', 'es'),
(10, 'Japonca', 'ja');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `project`
--

INSERT INTO `project` (`id`, `date`, `user_id`) VALUES
(4, '2019-01-23 05:23:41', 1),
(5, '2019-01-23 05:24:55', 1),
(6, '2019-01-23 10:15:17', 1),
(7, '2019-01-23 10:15:55', 1),
(8, '2019-01-23 10:18:01', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `project_detail`
--

CREATE TABLE `project_detail` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `version` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `project_detail`
--

INSERT INTO `project_detail` (`id`, `project_id`, `name`, `description`, `version`, `language_id`, `user_id`) VALUES
(5, 4, 'Kitap', 'Kitap Üretimi', 1, 1, 1),
(6, 4, 'Yeni Kitap Üretimi', 'Yeni Kitap Üretimi', 2, 1, 1),
(7, 4, 'Book Production', 'Book Production', 1, 2, 1),
(8, 4, 'New Book Production', 'New Book Production', 2, 2, 1),
(9, 5, 'Laptop Tasarımı', 'Laptop Tasarımı', 1, 1, 1),
(10, 5, 'Yeni Laptop Tasarımı', 'Yeni Laptop Tasarımı', 2, 1, 1),
(11, 5, 'Neuer Laptop-Entwurf', 'Neuer Laptop-Entwurf', 1, 3, 1),
(12, 5, 'V2 Neuer Laptop-Entwurf', 'V2 Neuer Laptop-Entwurf', 2, 3, 1),
(13, 4, 'إنتاج الكتاب', 'إنتاج الكتاب', 1, 5, 1),
(14, 4, 'La production de livres', 'La production de livres', 1, 4, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'kurumsal', 'admin'),
(4, 'busra', '1204busra'),
(5, 'test', 'test');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `version`
--

CREATE TABLE `version` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `version`
--

INSERT INTO `version` (`id`, `name`) VALUES
(1, 'Version 1.0'),
(2, 'Version 2.0'),
(3, 'Version 3.0'),
(4, 'Version 4.0'),
(5, 'Version 5.0');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `project_detail`
--
ALTER TABLE `project_detail`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `version`
--
ALTER TABLE `version`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `language`
--
ALTER TABLE `language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Tablo için AUTO_INCREMENT değeri `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `project_detail`
--
ALTER TABLE `project_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `version`
--
ALTER TABLE `version`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
